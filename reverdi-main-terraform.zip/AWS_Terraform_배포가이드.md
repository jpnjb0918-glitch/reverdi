# Reverdi AWS Terraform 배포 가이드

이 저장소의 기존 AWS 구성(`eksctl + CloudFormation + bash`)을 Terraform 중심으로 배포하도록 정리했습니다.

## 핵심 순서

```text
Terraform
  ├─ VPC / public+private subnet / NAT 1
  ├─ EKS control plane
  ├─ web / batch / infra managed node group
  ├─ EBS CSI + gp3
  ├─ ALB Controller
  ├─ Metrics Server
  ├─ ECR × 2
  ├─ S3
  ├─ RDS PostgreSQL 17
  │    ├─ Multi-AZ writer
  │    └─ read replica
  └─ IRSA
       ├─ ALB controller
       ├─ EBS CSI
       ├─ web → S3 R/W/D
       └─ batch → S3 PutObject only

선택 Helm
  ├─ Argo CD
  ├─ kube-prometheus-stack
  └─ Jenkins

두 번째 apply
  └─ ECR image tag가 준비되면 Reverdi Helm chart + migration + ALB
```

## 1. 준비

AWS 로그인 확인:

```powershell
aws sts get-caller-identity
aws configure
```

필요한 도구:

- Terraform 1.11+
- AWS CLI
- kubectl
- Helm
- Docker(이미지 push 시)

Terraform provider는 2026-09 기준 AWS provider 6.62 계열을 사용하도록 작성했습니다. Terraform AWS Provider 6.62.0이 현재 최신으로 Registry에 게시되어 있습니다. citeturn0search1

## 2. 첫 배포

```powershell
cd terraform
copy terraform.tfvars.example terraform.tfvars
terraform init
terraform plan
terraform apply
```

처음에는:

```hcl
deploy_app = false
```

로 두세요.

RDS/EKS가 만들어지는 동안 20~40분 정도 걸릴 수 있습니다.

## 3. 이미지 push

Terraform이 ECR repository를 만들지만 애플리케이션 이미지를 대신 빌드하지는 않습니다.

출력 확인:

```powershell
terraform output ecr_backend_repository
terraform output ecr_crawler_repository
```

두 repository에 **동일한 tag**를 push합니다.

```powershell
aws ecr get-login-password --region ap-northeast-2 |
  docker login --username AWS --password-stdin <ACCOUNT>.dkr.ecr.ap-northeast-2.amazonaws.com
```

이미지는 기존 프로젝트의 실제 Dockerfile 위치에 맞춰 빌드합니다.

ARM Mac에서 빌드하는 경우 기존 가이드와 동일하게:

```bash
docker build --platform linux/amd64 ...
```

를 사용하세요.

## 4. 앱 배포

`terraform.tfvars`:

```hcl
deploy_app = true
image_tag  = "git-abcdef1"
```

그리고:

```powershell
terraform apply
```

Helm pre-install/pre-upgrade migration이 먼저 실행되고 이후 웹 Deployment가 올라갑니다.

## 5. 접속

```powershell
aws eks update-kubeconfig --region ap-northeast-2 --name reverdi

kubectl get nodes -L workload,topology.kubernetes.io/zone
kubectl get pods -n reverdi -o wide
kubectl get ingress -n reverdi
```

ALB DNS를 확인하고:

```powershell
curl http://<ALB-DNS>/health
curl http://<ALB-DNS>/ready
```

`/ready`에서 database와 storage가 정상인지 확인합니다.

특히:

```json
"storage": {
  "mode": "s3",
  "ok": true
}
```

여야 합니다.

## 6. HTTP / HTTPS

도메인과 ACM 인증서가 아직 없으면 HTTP 80으로 동작합니다.

이 경우 `COOKIE_SECURE=false`가 자동 적용됩니다.

ACM 인증서가 준비되면:

```hcl
domain = "example.example.com"
acm_certificate_arn = "arn:aws:acm:ap-northeast-2:..."
```

로 바꾸고 다시:

```powershell
terraform apply
```

합니다.

그러면:

- HTTP 80
- HTTPS 443
- HTTPS redirect
- `COOKIE_SECURE=true`

가 적용됩니다.

## 7. Argo CD / Grafana / Jenkins

세 도구는 인터넷에 직접 NodePort로 노출하지 않고 ClusterIP로 배포합니다.

Argo CD:

```powershell
kubectl port-forward -n argocd svc/argocd-server 8080:80
```

Grafana:

```powershell
kubectl port-forward -n monitoring svc/kps-grafana 3000:80
```

Jenkins:

```powershell
kubectl port-forward -n infra svc/jenkins 8081:8080
```

Jenkins는 배치 노드에서 동적 Buildah agent를 만들도록 기존 값을 그대로 사용합니다.

## 8. 중요한 보안 사항

Terraform에서 앱 Secret을 생성하기 때문에:

```text
DATABASE_PASSWORD
SESSION_SECRET
ADMIN_PASSWORD
CLIENT_PASSWORD
```

등이 Terraform state에 저장됩니다.

따라서 실제 팀/운영 환경에서는 반드시:

- 암호화된 remote state
- S3 backend
- state 접근 IAM 최소화
- state 버전 관리/잠금

등을 적용하세요.

데모를 위해 로컬 state를 사용하더라도 `terraform.tfstate`를 Git에 절대 커밋하지 않습니다.

## 9. 기존 파일에서 확인한 중요한 문제와 수정

### ① 기존 AWS 스크립트는 Terraform으로 통합

기존:

```text
eksctl
CloudFormation
aws cli
kubectl
helm
```

을 각각 실행하던 구조를 Terraform dependency graph로 묶었습니다.

### ② EBS CSI IRSA 연결 문제

기존 문서에서 가장 위험했던 부분 중 하나입니다.

`aws-ebs-csi-driver` addon과 IRSA 역할을 별개로 생성하면 PVC가 조용히 Pending 될 수 있었습니다.

Terraform에서는 EBS CSI IAM role을 만든 뒤 `aws_eks_addon`에 직접 연결합니다.

### ③ ServiceAccount 누락

기존 `values-aws.yaml`은:

```yaml
serviceAccountName: reverdi-web
batchServiceAccountName: reverdi-batch
```

을 사용하지만 chart 안에는 해당 ServiceAccount template이 없습니다.

Terraform에서 두 ServiceAccount를 생성하고 각각 IRSA role을 annotation 합니다.

### ④ RDS

기존 CloudFormation 설계:

```text
PostgreSQL 17
Multi-AZ
read replica
private subnet
force SSL
encrypted
```

을 그대로 유지했습니다.

### ⑤ S3 권한 분리

웹:

```text
GetObject
PutObject
DeleteObject
ListBucket
```

배치:

```text
PutObject only
```

로 분리했습니다.

크롤러가 뚫려도 웹의 삭제 권한이나 관리자 비밀번호를 그대로 갖지 않는 구조입니다.

### ⑥ HTTP에서 Secure Cookie 문제

원본 `values-aws.yaml`에는 HTTP ALB인데 `COOKIE_SECURE=true`가 들어 있었습니다.

Terraform 버전에서는:

- 인증서 없음 → HTTP + `COOKIE_SECURE=false`
- 인증서 있음 → HTTPS + `COOKIE_SECURE=true`

로 자동 결정합니다.

### ⑦ X-Forwarded-For

앱에서 `TRUST_PROXY_HEADERS=true`를 사용하므로 ALB가 XFF를 덮어쓰도록:

```text
routing.http.xff_header_processing.mode=replace
```

를 설정했습니다.

## 10. 삭제

데모가 끝났으면:

```powershell
terraform destroy
```

합니다.

현재 구성은 데모용으로:

- RDS final snapshot 생략
- S3 force destroy
- deletion protection 비활성화

이므로 운영 DB에는 그대로 사용하면 안 됩니다.

## 11. 비용

현재 설계는 의도적으로:

```text
EKS
NAT Gateway 1
web t3.medium ×3
batch t3.medium ×1
infra t3.medium ×1
RDS db.t4g.small Multi-AZ
RDS read replica db.t4g.small
EBS
S3
ECR
CloudWatch Logs
```

가 들어갑니다.

특히 **RDS Multi-AZ + read replica + 5대 EC2 + NAT Gateway**가 데모 비용의 핵심입니다.

발표/시연이 끝난 날은 전체 destroy가 가장 확실합니다.
